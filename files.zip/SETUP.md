# Mario Contribution Graph Animation

Mario runs across your GitHub contribution graph, hopping up onto active
("green") squares and skipping over inactive ("dark") ones — the same trick
as the popular Snake animation, but Mario.

## How it works

- `scripts/generate.mjs` fetches your public contribution calendar (no
  token needed — uses the same public mirror API many of these tools use)
  and renders an animated SVG. For each week column it picks the most
  active day and uses that to decide whether Mario jumps (green/landable)
  or runs straight through (dark/not landable).
- `.github/workflows/mario.yml` runs that script once a day (and on every
  push) and commits the resulting `output/mario.svg` back into your repo,
  so the animation always reflects your latest activity — exactly how the
  Snake repos keep themselves up to date.

## Setup (5 minutes)

1. Create a **public** repository named exactly `<your-username>` if you
   don't already have one — that's the special "profile README" repo
   GitHub looks for.
2. Copy these files into it, preserving the folder structure:
   - `scripts/generate.mjs`
   - `.github/workflows/mario.yml`
3. Commit and push. Go to the **Actions** tab and run the
   "Generate Mario contribution animation" workflow manually once
   (`Run workflow` button) so `output/mario.svg` gets created immediately
   instead of waiting for the nightly cron.
4. In your `README.md`, add:

   ```markdown
   ![Mario contribution graph](output/mario.svg)
   ```

   (Use the raw GitHub URL if you want it to work from anywhere, e.g. in
   another repo's README too:
   `https://raw.githubusercontent.com/<you>/<you>/main/output/mario.svg`
   — GitHub renders SVG `<animateTransform>` fine when embedded this way.)

5. Done — it'll silently refresh every day via the scheduled Action.

## Customizing

- **Colors**: edit `LEVEL_COLORS` in `generate.mjs` to match a different
  theme (there's also a `mario-dark.svg` variant generated automatically
  for dark-mode READMEs, using GitHub's `<picture>` light/dark image
  trick if you want both:

  ```markdown
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="output/mario-dark.svg">
    <img alt="Mario contribution graph" src="output/mario.svg">
  </picture>
  ```

- **Jump height / speed**: `jumpHeight` and `totalDuration` constants near
  the bottom of `buildSvg()`.
- **Mario's sprite**: he's just a handful of `<rect>` blocks under the
  `<g id="mario">` group, so you can restyle, recolor, or swap in Luigi
  colors easily without needing an external image asset (keeps the SVG
  fully self-contained, which matters since GitHub strips most external
  resources from embedded SVGs anyway).

## Notes

- This uses the **most active day per week** as a single landing platform
  per column, rather than trying to have Mario zigzag across all 7 rows —
  that keeps the run readable instead of looking chaotic. If you'd rather
  he traverse all 7 rows in sequence (closer to literal Snake-style
  movement), that's a straightforward change to the `cells` construction
  loop in `generate.mjs` — happy to build that variant too if you want it.
- If your profile has very few public contributions, most tiles will be
  dark and Mario will mostly just run in place at ground level — same as
  how Snake repos look sparse for low-activity profiles.
